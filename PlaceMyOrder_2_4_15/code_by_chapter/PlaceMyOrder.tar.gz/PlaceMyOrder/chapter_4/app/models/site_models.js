var RestaurantModel = can.Model.extend({
        findAll: "GET /restaurants"
    },
    //Include second, blank parameter object to set staticProperties
    {});