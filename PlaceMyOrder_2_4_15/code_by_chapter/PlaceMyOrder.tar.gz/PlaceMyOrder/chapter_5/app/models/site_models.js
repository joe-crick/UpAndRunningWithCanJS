var RestaurantModel = can.Model.extend({
        findAll: "GET /restaurants"
    },
    //Include second, blank parameter object to set staticProperties
    {});

/**
 * RestaurantMenusModel
 * @type {void|*}
 */
var RestaurantMenusModel = can.Model.extend({
        findOne: "GET /restaurantMenus/{id}"
    },
    {});

/**
 * Menu Order Model
 * @type {void|*}
 */
var MenuOrderModel = can.Model.extend({
        create: 'POST /createOrder',
        init: function () {
            //validates that the address field has been filled in
            this.validatePresenceOf('delivery.address');

            // validates that name is at least two chars long
            this.validate("delivery.name", function (name) {
                if (!name) {
                    return "Your name must be at least two characters long."
                }
                if (name.length < 2) {
                    return "Your name must be at least two characters long."
                }
            });

        }
    },
    {});