$(function () {

    $('#can-app').html('The Requisite "Hello World" Message');

});