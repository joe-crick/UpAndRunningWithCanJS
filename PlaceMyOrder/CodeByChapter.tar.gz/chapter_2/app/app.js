$(function () {

    $('#can-app').html(can.view('base_template.stache', {}));

});